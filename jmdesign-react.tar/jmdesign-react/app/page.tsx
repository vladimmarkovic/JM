'use client'

import { motion, useScroll, useTransform, useInView } from 'framer-motion'
import { useRef } from 'react'
import Link from 'next/link'

// Animation Variants
const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] }
  }
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2
    }
  }
}

const scaleIn = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { 
    opacity: 1, 
    scale: 1,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
  }
}

export default function HomePage() {
  const heroRef = useRef(null)
  const servicesRef = useRef(null)
  const statsRef = useRef(null)
  
  const servicesInView = useInView(servicesRef, { once: true, amount: 0.2 })
  const statsInView = useInView(statsRef, { once: true, amount: 0.3 })

  const { scrollYProgress } = useScroll()
  const heroY = useTransform(scrollYProgress, [0, 1], ['0%', '50%'])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0])

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
        {/* Animated Background */}
        <div className="absolute inset-0 gradient-mesh">
          <motion.div
            className="absolute top-1/4 left-1/3 w-96 h-96 bg-ice-cyan/20 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              x: [0, 50, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/3 w-96 h-96 bg-energy/10 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.3, 1],
              x: [0, -50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 1,
            }}
          />
        </div>

        <motion.div
          ref={heroRef}
          style={{ y: heroY, opacity: heroOpacity }}
          className="container-custom px-4 md:px-8 relative z-10"
        >
          <div className="max-w-5xl mx-auto text-center">
            {/* Overline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full bg-ice-cyan/10 border border-ice-cyan/20 backdrop-blur-sm"
            >
              <div className="w-2 h-2 rounded-full bg-ice-cyan animate-pulse" />
              <span className="font-display text-sm uppercase tracking-wider text-ice-cyan font-semibold">
                Tehničko-Tehnološko Projektovanje
              </span>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="text-5xl md:text-7xl lg:text-8xl font-display font-black mb-8 leading-[1.1]"
            >
              <span className="text-glow inline-block">
                Pretvaramo Ideje
              </span>
              <br />
              <span className="text-frost inline-block mt-2">
                u Profitabilne
              </span>
              <br />
              <span className="relative inline-block mt-2">
                <span className="relative z-10 text-frost">Proizvodne Pogone</span>
                <motion.span
                  className="absolute inset-0 bg-gradient-to-r from-ice-cyan/20 to-ice-mint/20 blur-2xl"
                  animate={{
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                />
              </span>
            </motion.h1>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="text-lg md:text-xl lg:text-2xl text-metal max-w-3xl mx-auto mb-12 leading-relaxed font-light"
            >
              Projektujemo i gradimo kompletne fabrike za proizvodnju sladoleda, 
              smrznutog povrća i prehrambenih proizvoda. Od koncepta do realizacije.
            </motion.p>

            {/* Stats */}
            <motion.div
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
              className="flex flex-wrap justify-center gap-8 lg:gap-16 mb-12"
            >
              {[
                { value: '40+', label: 'Godina Iskustva' },
                { value: '100+', label: 'Uspešnih Projekata' },
                { value: '9.7', label: 'Zadovoljstvo Klijenata' },
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  variants={scaleIn}
                  className="relative group"
                >
                  <div className="text-center">
                    <motion.div
                      className="text-4xl md:text-6xl font-display font-black text-ice-cyan mb-2"
                      whileHover={{ scale: 1.1 }}
                      transition={{ type: 'spring', stiffness: 400 }}
                    >
                      {stat.value}
                    </motion.div>
                    <div className="text-sm md:text-base text-metal uppercase tracking-wider font-medium">
                      {stat.label}
                    </div>
                  </div>
                  <motion.div
                    className="absolute -inset-4 bg-ice-cyan/10 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"
                  />
                </motion.div>
              ))}
            </motion.div>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            >
              <Link href="/kontakt" className="btn-primary group">
                <span className="relative z-10">Zakažite Konsultacije</span>
              </Link>
              
              <Link href="/projekti" className="btn-secondary">
                Pogledajte Projekte
              </Link>
            </motion.div>

            {/* Scroll Indicator */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
              className="absolute bottom-8 left-1/2 -translate-x-1/2"
            >
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="w-6 h-10 border-2 border-ice-cyan/30 rounded-full p-1"
              >
                <motion.div
                  animate={{ y: [0, 20, 0], opacity: [1, 0, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="w-1 h-2 bg-ice-cyan rounded-full mx-auto"
                />
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* Services Section */}
      <section ref={servicesRef} className="section bg-gradient-to-b from-steel-900 to-steel-800">
        <div className="container-custom">
          <motion.div
            initial="hidden"
            animate={servicesInView ? "visible" : "hidden"}
            variants={staggerContainer}
            className="text-center mb-16"
          >
            <motion.div variants={fadeInUp} className="mb-4">
              <span className="font-display text-sm uppercase tracking-wider text-energy font-semibold">
                Naše Usluge
              </span>
            </motion.div>
            <motion.h2 
              variants={fadeInUp}
              className="text-4xl md:text-5xl lg:text-6xl font-display font-black text-frost mb-6"
            >
              Kompleksna Inženjerska Rešenja
            </motion.h2>
            <motion.p 
              variants={fadeInUp}
              className="text-lg md:text-xl text-metal max-w-3xl mx-auto"
            >
              Specijalizovani smo za projektovanje, izgradnju i optimizaciju kompletnih 
              proizvodnih pogona sa fokusom na maksimalnu efikasnost.
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            animate={servicesInView ? "visible" : "hidden"}
            variants={staggerContainer}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {[
              {
                icon: '🏭',
                title: 'Fabrike za Sladoled',
                description: 'Kompletno projektovanje fabrika za industrijsku proizvodnju sladoleda sa kapacitetom do 10 tona dnevno.',
                stats: ['2-20t/dan', '-40°C IQF', 'PLC Kontrola']
              },
              {
                icon: '❄️',
                title: 'Hladnjače -26°C',
                description: 'Projektovanje velikih hladnjača za dugoročno skladištenje zamrznutih proizvoda.',
                stats: ['Do 5000 paleta', '-26°C', 'SCADA Sistem']
              },
              {
                icon: '🥦',
                title: 'Pogoni za Povrće',
                description: 'Linije za industrijsku proizvodnju smrznutog povrća sa potpunom automatizacijom.',
                stats: ['5-20t/sat', 'IQF Tunel', 'Blanširanje']
              },
              {
                icon: '📐',
                title: 'Tehnička Dokumentacija',
                description: 'Izrada potpune tehničko-konstrukcione dokumentacije za proizvodne linije.',
                stats: ['3D Modeli', 'FEM Analiza', 'BOM Liste']
              },
              {
                icon: '⚡',
                title: 'Energetska Optimizacija',
                description: 'Tehničko savetovanje za optimalno korišćenje energije i sirovine.',
                stats: ['20-35% Ušteda', 'ROI Analiza', 'Monitoring']
              },
              {
                icon: '🔧',
                title: 'Tehničko Održavanje',
                description: 'Kompletne usluge tehničkog održavanja proizvodnih pogona i opreme.',
                stats: ['24/7 Servis', 'Preventiva', 'Upgrade']
              },
            ].map((service, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                whileHover={{ y: -10 }}
                className="card group perspective-1000"
              >
                <motion.div
                  whileHover={{ rotateY: 5, rotateX: 5 }}
                  transition={{ type: 'spring', stiffness: 300 }}
                  className="transform-3d"
                >
                  {/* Icon */}
                  <motion.div
                    className="text-6xl mb-6 filter drop-shadow-[0_10px_30px_rgba(0,212,255,0.4)]"
                    whileHover={{ scale: 1.1, rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    {service.icon}
                  </motion.div>

                  {/* Title */}
                  <h3 className="font-display text-xl md:text-2xl font-bold text-frost mb-4 group-hover:text-ice-cyan transition-colors duration-300">
                    {service.title}
                  </h3>

                  {/* Description */}
                  <p className="text-metal mb-6 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Stats */}
                  <div className="flex flex-wrap gap-2">
                    {service.stats.map((stat, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 text-xs font-semibold bg-ice-cyan/10 text-ice-cyan border border-ice-cyan/20 rounded-sm uppercase tracking-wider"
                      >
                        {stat}
                      </span>
                    ))}
                  </div>

                  {/* Link */}
                  <div className="mt-6 inline-flex items-center gap-2 text-ice-cyan font-display text-sm uppercase tracking-wider font-semibold group-hover:gap-4 transition-all duration-300">
                    <span>Saznajte Više</span>
                    <motion.span
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      →
                    </motion.span>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Process Section */}
      <section className="section bg-steel-900">
        <div className="container-custom">
          <div className="text-center mb-16">
            <span className="font-display text-sm uppercase tracking-wider text-energy font-semibold mb-4 block">
              Naš Pristup
            </span>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-black text-frost mb-6">
              Od Ideje do Realizacije
            </h2>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {/* Connection Line */}
              <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-ice-cyan via-ice-mint to-ice-cyan md:block hidden" />

              {[
                { num: '01', title: 'Konsultacije', desc: 'Analiza vaših potreba, ciljeva i mogućnosti.' },
                { num: '02', title: 'Projektovanje', desc: 'Kompletna tehničko-tehnološka dokumentacija i 3D modeli.' },
                { num: '03', title: 'Izgradnja', desc: 'Nadzor nad izvođenjem radova i instalacijom opreme.' },
                { num: '04', title: 'Podrška', desc: 'Obuka osoblja, optimizacija i kontinuirana podrška.' },
              ].map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="relative flex gap-8 mb-12 last:mb-0 group"
                >
                  {/* Number Circle */}
                  <motion.div
                    whileHover={{ scale: 1.15, rotate: 360 }}
                    transition={{ duration: 0.6 }}
                    className="relative flex-shrink-0 w-16 h-16 rounded-full bg-gradient-to-br from-steel-700 to-freeze border-2 border-ice-cyan flex items-center justify-center font-display text-2xl font-black text-ice-cyan shadow-[0_10px_40px_rgba(0,212,255,0.3)] z-10"
                  >
                    {step.num}
                  </motion.div>

                  {/* Content */}
                  <div className="flex-1 pt-2">
                    <h3 className="font-display text-2xl font-bold text-frost mb-2 group-hover:text-ice-cyan transition-colors duration-300">
                      {step.title}
                    </h3>
                    <p className="text-metal text-lg leading-relaxed">
                      {step.desc}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section gradient-mesh relative overflow-hidden">
        <div className="container-custom text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-black mb-6">
              <span className="text-glow">
                Spremni da Pretvorite
                <br />
                Vašu Ideju u Realnost?
              </span>
            </h2>
            <p className="text-xl md:text-2xl text-metal max-w-3xl mx-auto mb-8">
              Pozovite nas bez ustručavanja! Potpuno besplatno ćemo sagledati 
              vaše ideje i mogućnosti realizacije.
            </p>
            <Link href="/kontakt" className="btn-primary inline-block">
              <span className="relative z-10">Zakažite Besplatne Konsultacije</span>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

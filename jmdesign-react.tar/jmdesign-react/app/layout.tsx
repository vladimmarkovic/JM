import { Inter } from 'next/font/google'
import localFont from 'next/font/local'
import './globals.css'
import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const syne = localFont({
  src: [
    {
      path: '../public/fonts/Syne-Bold.woff2',
      weight: '700',
      style: 'normal',
    },
    {
      path: '../public/fonts/Syne-ExtraBold.woff2',
      weight: '800',
      style: 'normal',
    },
  ],
  variable: '--font-syne',
  display: 'swap',
})

export const metadata = {
  title: 'JM Design - Projektovanje Fabrika za Sladoled i Prehrambenu Industriju',
  description: '40+ godina iskustva u projektovanju fabrika za sladoled, hladnjača -26°C i proizvodnih pogona. 100+ uspešnih projekata.',
  keywords: 'projektovanje fabrike sladoleda, hladnjače, proizvodnja povrća, tehničko projektovanje',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="sr" className={`${inter.variable} ${syne.variable}`}>
      <body className="bg-steel-900 text-frost antialiased overflow-x-hidden">
        {/* Animated Background Grid */}
        <div className="fixed inset-0 pointer-events-none z-0">
          <div className="absolute inset-0 bg-[linear-gradient(rgba(0,212,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,212,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px] animate-pulse" />
          
          {/* Glow Effects */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-ice-cyan/10 rounded-full blur-3xl animate-glow-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-energy/5 rounded-full blur-3xl animate-glow-pulse animation-delay-2000" />
        </div>

        <div className="relative z-10">
          <Navigation />
          <main className="min-h-screen">
            {children}
          </main>
          <Footer />
        </div>
      </body>
    </html>
  )
}

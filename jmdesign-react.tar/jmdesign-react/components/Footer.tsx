'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'

const footerLinks = {
  pages: [
    { label: 'Početna', href: '/' },
    { label: 'O Nama', href: '/o-nama' },
    { label: 'Usluge', href: '/usluge' },
    { label: 'Projekti', href: '/projekti' },
    { label: 'Kontakt', href: '/kontakt' },
  ],
  services: [
    'Fabrike Sladoleda',
    'Hladnjače -26°C',
    'Pogoni za Povrće',
    'Tehničko Savetovanje',
    'Konstrukciona Dokumentacija',
  ],
}

export default function Footer() {
  return (
    <footer className="relative bg-steel-800 border-t border-ice-cyan/10">
      <div className="container-custom px-4 md:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="font-display text-2xl font-bold text-ice-cyan mb-4">
              JM DESIGN
            </h3>
            <p className="text-metal leading-relaxed">
              Tehničko-tehnološko projektovanje za prehrambenu industriju 
              sa 40+ godina iskustva.
            </p>
          </motion.div>

          {/* Pages */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h3 className="font-display text-lg font-bold text-ice-cyan mb-4 uppercase tracking-wider">
              Stranice
            </h3>
            <ul className="space-y-3">
              {footerLinks.pages.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-metal hover:text-ice-cyan transition-colors duration-300 inline-flex items-center gap-2 group"
                  >
                    <span className="w-0 h-px bg-ice-cyan group-hover:w-4 transition-all duration-300" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="font-display text-lg font-bold text-ice-cyan mb-4 uppercase tracking-wider">
              Usluge
            </h3>
            <ul className="space-y-3">
              {footerLinks.services.map((service, index) => (
                <li key={index} className="text-metal">
                  {service}
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="font-display text-lg font-bold text-ice-cyan mb-4 uppercase tracking-wider">
              Kontakt
            </h3>
            <div className="space-y-3 text-metal">
              <a
                href="mailto:info@jmdesign.rs"
                className="block hover:text-ice-cyan transition-colors duration-300"
              >
                info@jmdesign.rs
              </a>
              <a
                href="mailto:jelenamincic.jm@gmail.com"
                className="block hover:text-ice-cyan transition-colors duration-300"
              >
                jelenamincic.jm@gmail.com
              </a>
              <a
                href="mailto:danemincic.dm@gmail.com"
                className="block hover:text-ice-cyan transition-colors duration-300"
              >
                danemincic.dm@gmail.com
              </a>
            </div>
          </motion.div>
        </div>

        {/* Bottom Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="pt-8 border-t border-metal/10 text-center"
        >
          <p className="text-metal text-sm">
            © {new Date().getFullYear()} JM Design. Sva prava zadržana.
          </p>
        </motion.div>
      </div>

      {/* Background Glow */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-ice-cyan/5 rounded-full blur-3xl pointer-events-none" />
    </footer>
  )
}

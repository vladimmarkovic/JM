'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, useScroll, useTransform } from 'framer-motion'

const navLinks = [
  { href: '/', label: 'Početna' },
  { href: '/o-nama', label: 'O Nama' },
  { href: '/usluge', label: 'Usluge' },
  { href: '/projekti', label: 'Projekti' },
  { href: '/kontakt', label: 'Kontakt' },
]

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const pathname = usePathname()
  const { scrollY } = useScroll()

  // Change nav background on scroll
  const navBackground = useTransform(
    scrollY,
    [0, 100],
    ['rgba(10, 24, 40, 0.7)', 'rgba(10, 24, 40, 0.95)']
  )

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.header
      style={{ backgroundColor: navBackground }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? 'backdrop-blur-xl shadow-[0_8px_32px_rgba(0,212,255,0.1)]' : 'backdrop-blur-md'
      } border-b border-ice-cyan/10`}
    >
      <nav className="container-custom px-4 md:px-8">
        <div className="flex items-center justify-between h-20 md:h-24">
          {/* Logo */}
          <Link href="/" className="group relative">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="font-display text-2xl md:text-3xl font-extrabold uppercase tracking-[0.3em] text-ice-cyan relative"
            >
              JM DESIGN
              <motion.div
                className="absolute -inset-2 bg-ice-cyan/20 blur-xl rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                animate={{
                  scale: [1, 1.1, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              />
            </motion.div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8 lg:gap-12">
            {navLinks.map((link, index) => {
              const isActive = pathname === link.href
              return (
                <motion.div
                  key={link.href}
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="relative"
                >
                  <Link
                    href={link.href}
                    className={`relative font-medium text-sm lg:text-base tracking-wider transition-colors duration-300 ${
                      isActive ? 'text-ice-cyan' : 'text-frost hover:text-ice-cyan'
                    }`}
                  >
                    {link.label}
                    
                    {/* Active Indicator */}
                    {isActive && (
                      <motion.div
                        layoutId="activeNav"
                        className="absolute -bottom-2 left-0 right-0 h-0.5 bg-gradient-to-r from-ice-cyan to-ice-mint"
                        transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                      />
                    )}
                    
                    {/* Hover Effect */}
                    <span className="absolute -bottom-2 left-0 w-0 h-0.5 bg-ice-cyan/50 transition-all duration-300 group-hover:w-full" />
                  </Link>
                </motion.div>
              )
            })}

            {/* CTA Button */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <Link
                href="/kontakt"
                className="relative px-6 py-2.5 font-display font-bold text-sm uppercase tracking-wider bg-gradient-to-r from-ice-cyan to-ice-mint text-steel-900 rounded-sm overflow-hidden group"
              >
                <span className="relative z-10">Konsultacije</span>
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-ice-mint to-ice-cyan"
                  initial={{ x: '100%' }}
                  whileHover={{ x: 0 }}
                  transition={{ duration: 0.3 }}
                />
              </Link>
            </motion.div>
          </div>

          {/* Mobile Menu Button */}
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="md:hidden relative w-10 h-10 flex flex-col items-center justify-center gap-1.5 group"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            <motion.span
              animate={{
                rotate: isMobileMenuOpen ? 45 : 0,
                y: isMobileMenuOpen ? 8 : 0,
              }}
              className="w-6 h-0.5 bg-ice-cyan transition-colors group-hover:bg-ice-mint"
            />
            <motion.span
              animate={{
                opacity: isMobileMenuOpen ? 0 : 1,
              }}
              className="w-6 h-0.5 bg-ice-cyan transition-colors group-hover:bg-ice-mint"
            />
            <motion.span
              animate={{
                rotate: isMobileMenuOpen ? -45 : 0,
                y: isMobileMenuOpen ? -8 : 0,
              }}
              className="w-6 h-0.5 bg-ice-cyan transition-colors group-hover:bg-ice-mint"
            />
          </motion.button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{
          opacity: isMobileMenuOpen ? 1 : 0,
          height: isMobileMenuOpen ? 'auto' : 0,
        }}
        transition={{ duration: 0.3 }}
        className="md:hidden overflow-hidden bg-steel-800/95 backdrop-blur-xl border-t border-ice-cyan/10"
      >
        <div className="container-custom px-4 py-6 space-y-4">
          {navLinks.map((link, index) => {
            const isActive = pathname === link.href
            return (
              <motion.div
                key={link.href}
                initial={{ opacity: 0, x: -20 }}
                animate={{
                  opacity: isMobileMenuOpen ? 1 : 0,
                  x: isMobileMenuOpen ? 0 : -20,
                }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Link
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`block py-3 px-4 rounded-lg font-medium text-lg transition-all duration-300 ${
                    isActive
                      ? 'bg-ice-cyan/10 text-ice-cyan border-l-4 border-ice-cyan'
                      : 'text-frost hover:bg-steel-700/50 hover:text-ice-cyan'
                  }`}
                >
                  {link.label}
                </Link>
              </motion.div>
            )
          })}
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{
              opacity: isMobileMenuOpen ? 1 : 0,
              y: isMobileMenuOpen ? 0 : 20,
            }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="pt-4"
          >
            <Link
              href="/kontakt"
              onClick={() => setIsMobileMenuOpen(false)}
              className="block py-4 px-6 text-center font-display font-bold uppercase tracking-wider bg-gradient-to-r from-ice-cyan to-ice-mint text-steel-900 rounded-sm"
            >
              Zakažite Konsultacije
            </Link>
          </motion.div>
        </div>
      </motion.div>
    </motion.header>
  )
}

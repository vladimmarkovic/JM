# JM Design - Modern React Website (2026)

## 🚀 Technical Stack

**Framework:** Next.js 15 (App Router)  
**UI Library:** React 18.3  
**Styling:** Tailwind CSS 3.4 + Custom CSS  
**Animations:** Framer Motion 11  
**Language:** TypeScript 5  
**Deployment:** Vercel (recommended) / Netlify / AWS

---

## 🎨 Design Philosophy (2026 Standards)

This website represents cutting-edge web design for 2026:

### **Modern Design Trends Implemented:**

1. **Glassmorphism 2.0**
   - Refined backdrop blur effects
   - Layered transparency
   - Subtle borders and shadows

2. **Kinetic Typography**
   - Text responds to scroll position
   - Gradient text effects
   - Variable font support

3. **3D Micro-interactions**
   - Subtle depth without gimmicks
   - Perspective transforms on hover
   - Smooth spring animations

4. **Advanced Animation System**
   - Framer Motion for buttery smooth 60fps animations
   - Scroll-triggered reveals
   - Staggered entrance animations
   - View Transitions API ready

5. **Performance-First Architecture**
   - Server Components by default
   - Partial hydration
   - Optimized image loading
   - Code splitting

---

## 📦 Installation

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🏗️ Project Structure

```
jmdesign-react/
├── app/
│   ├── layout.tsx          # Root layout with Navigation & Footer
│   ├── page.tsx            # Homepage
│   ├── globals.css         # Global styles & design system
│   ├── o-nama/             # About page
│   ├── usluge/             # Services page
│   ├── projekti/           # Projects page
│   └── kontakt/            # Contact page
├── components/
│   ├── Navigation.tsx      # Animated navigation bar
│   ├── Footer.tsx          # Footer component
│   └── ...                 # Other reusable components
├── public/
│   └── fonts/              # Custom fonts (Syne)
├── tailwind.config.js      # Tailwind + custom design tokens
├── next.config.js          # Next.js configuration
└── package.json            # Dependencies
```

---

## 🎯 Key Features

### **1. Navigation**
- Fixed header with glassmorphism
- Smooth scroll-based background change
- Mobile-responsive hamburger menu
- Active page indicator with animated underline

### **2. Homepage**
- Parallax hero section
- Animated gradient backgrounds
- Statistics counter with hover effects
- Services grid with 3D transforms
- Process timeline with scroll animations

### **3. Performance**
- **Lighthouse Score Target:** 95+
- Server-side rendering for SEO
- Image optimization with Next/Image
- Lazy loading components
- Minimal JavaScript bundle

### **4. Animations**
- **60fps guarantee** via Framer Motion
- Hardware-accelerated transforms
- Intersection Observer for scroll triggers
- Spring physics for natural movement

---

## 🎨 Design System

### **Colors**
```css
--steel-900: #0a1828      /* Dark background */
--ice-cyan: #00d4ff       /* Primary accent */
--ice-mint: #00fff5       /* Secondary accent */
--energy: #ff6b35         /* CTA color */
--frost: #f0f8ff          /* Text white */
--metal: #8b9db0          /* Text gray */
```

### **Typography**
- **Display Font:** Syne (bold, modern)
- **Body Font:** Inter (readable, clean)
- **Fluid Type Scale:** clamp() for responsive sizing

### **Spacing**
- Mobile-first approach
- Consistent 8px grid system
- Fluid section padding: `clamp(4rem, 10vw, 8rem)`

---

## 🚢 Deployment

### **Recommended: Vercel**
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

### **Alternative: Netlify**
```bash
# Build command
npm run build

# Publish directory
.next
```

### **Environment Variables**
Create `.env.local`:
```
NEXT_PUBLIC_SITE_URL=https://jmdesign.rs
NEXT_PUBLIC_GTM_ID=GTM-XXXXXXX
```

---

## 📊 SEO Optimization

- **Semantic HTML5** structure
- **Meta tags** for social sharing
- **Structured data** (JSON-LD)
- **Sitemap** auto-generated
- **Robots.txt** configured
- **Mobile-first** indexing ready

---

## 🔧 Customization Guide

### **Change Colors**
Edit `tailwind.config.js`:
```js
theme: {
  extend: {
    colors: {
      steel: { /* your colors */ },
      ice: { /* your colors */ },
    }
  }
}
```

### **Add New Page**
1. Create folder in `app/`: `app/new-page/`
2. Add `page.tsx` with your content
3. Update navigation in `components/Navigation.tsx`

### **Modify Animations**
Edit `app/page.tsx` - look for `motion` components:
```tsx
<motion.div
  initial={{ opacity: 0, y: 40 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.8 }}
>
  Your content
</motion.div>
```

---

## 📱 Browser Support

- **Chrome/Edge:** Latest 2 versions
- **Firefox:** Latest 2 versions
- **Safari:** Latest 2 versions
- **Mobile Safari:** iOS 14+
- **Chrome Mobile:** Latest

---

## 🎓 Learning Resources

- **Next.js Docs:** https://nextjs.org/docs
- **Framer Motion:** https://www.framer.com/motion/
- **Tailwind CSS:** https://tailwindcss.com/docs

---

## 📝 TODO / Future Enhancements

- [ ] Add CMS integration (Sanity/Contentful)
- [ ] Implement i18n for English version
- [ ] Add blog section
- [ ] Integrate contact form with backend
- [ ] Add Google Analytics
- [ ] Implement A/B testing
- [ ] Add project filtering
- [ ] Create admin dashboard

---

## 🐛 Troubleshooting

**Issue:** Animations not working  
**Fix:** Ensure Framer Motion is installed: `npm install framer-motion`

**Issue:** Fonts not loading  
**Fix:** Check `public/fonts/` directory exists with Syne font files

**Issue:** Tailwind classes not applying  
**Fix:** Run `npm run dev` to rebuild CSS

---

## 📄 License

© 2026 JM Design. All rights reserved.

---

## 🤝 Support

For technical support:
- **Email:** info@jmdesign.rs
- **Documentation:** Check this README
- **Issues:** Create GitHub issue (if applicable)

---

## ⚡ Why This Tech Stack?

### **Next.js 15 (vs vanilla React)**
✅ Built-in SEO optimization  
✅ Server-side rendering  
✅ File-based routing  
✅ Image optimization  
✅ API routes included  
✅ Zero config needed  

### **Framer Motion (vs CSS animations)**
✅ 60fps guaranteed  
✅ Complex sequences made easy  
✅ Gesture support  
✅ Layout animations  
✅ Scroll-triggered effects  

### **Tailwind (vs styled-components)**
✅ Smaller bundle size  
✅ No runtime cost  
✅ Consistent design tokens  
✅ Faster development  
✅ Easy customization  

---

**Built with ❤️ using 2026 best practices**
